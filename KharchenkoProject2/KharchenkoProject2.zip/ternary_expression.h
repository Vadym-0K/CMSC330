// CMSC 330 Advanced Programming Languages
// Project 2 
// Vadym Kharchenko
// October 3, 2024

// This is an organizer header that combines all the ternary expressions.

#include "unary.h"