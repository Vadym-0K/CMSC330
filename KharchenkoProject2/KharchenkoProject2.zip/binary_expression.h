// CMSC 330 Advanced Programming Languages
// Project 2 
// Vadym Kharchenko
// October 3, 2024

//This is just a grouping header to combine all the binary operations.

#include "divide.h"
#include "multiply.h"
#include "plus.h"
#include "minus.h"
#include "exponent.h"
#include "maximum.h"
#include "minimum.h"
#include "remainder.h"
#include "average.h"